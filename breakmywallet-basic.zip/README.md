# BreakMyWallet — Basic Starter

Minimal Next.js + Tailwind starter to verify deploy.

## Quickstart
npm i
npm run dev

## Deploy
- Push to GitHub
- Import to Vercel (defaults OK)
- Add domain in Vercel and set GoDaddy DNS:
  - A @ -> 76.76.21.21
  - CNAME www -> cname.vercel-dns.com
